#ifndef Header_h
#define Header_h

enum class cellType{ wall, tile, passage, door, stair, whiteSpace};

#endif /* Header_h */

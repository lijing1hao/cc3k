#ifndef ItemType_h
#define ItemType_h

enum class ItemType { hp, atk, def, gold };

#endif

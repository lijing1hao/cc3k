

#ifndef characterType_h
#define characterType_h

enum class characterType{human, dwarf, elf, orc, merchant, dragon, halfling,
shade, drow, vampire, troll, goblin};

#endif /* characterType_h */
